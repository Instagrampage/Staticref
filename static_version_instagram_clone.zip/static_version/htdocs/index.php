<?php
// Tüm dosyaları ana dizine yönlendir
header("Location: /");
exit();
?>